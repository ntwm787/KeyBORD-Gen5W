# KeyBORD 2.01 source

Editable source for the KeyBORD packages (NEMESIS package-version 2.0.1):

- packages/keyboard.hackers: keyboard APK installation and uninstall hooks.
- packages/keyboard.activate: KeyBridge selection and restoration hooks.
- packages/keyboard.restore: factory keyboard selection and restoration hooks.

Each package directory includes NEMESIS.data and the shell scripts it references.
Original KeyBORD scripts are licensed GPL-3.0-only; complete license texts are
included. Review scripts/common.sh for selection/snapshot logic and scripts/
for the package lifecycle hooks. No NEMESIS software is bundled.

## Build

Python 3 is required. Supply the unchanged Hacker's Keyboard 1.41.1 APK from
the KeyBORD keyboard installer (app/HackersKeyboard.apk inside keyboard.hackers.zip):

    python build.py --apk /path/to/HackersKeyboard.apk --out dist

On Windows, quote paths containing spaces. The build creates three standalone
NEMESIS packages with NEMESIS.data at each ZIP root. It does not install anything.
The binary APK is excluded from this source archive; its expected SHA-256 is:

641ab8a614f496765bb841665aa894fdb9d1f908c22ffb01af2059c7600ed0d3

## Third-party source and licenses

Hacker's Keyboard 1.41.1 is an Apache-2.0 upstream application, not original
KeyBORD code. Its source is available at:
https://github.com/klausw/hackerskeyboard/tree/1.41.1
The corresponding license and collected upstream notices are included under
packages/keyboard.hackers/licenses/. Preserve applicable copyright, license
and NOTICE material when redistributing it. This build packages the supplied
APK without modifying it; it does not compile the upstream Android application.

NEMESIS is separate and retains AGPL-3.0:
https://github.com/xwtk/hmg_nemesis

## Publish the source

Commit these files as ordinary readable files to:
https://github.com/ntwm787/KeyBORD-Gen5W

For example, place packages/ and build.py at the repository root and add this
README's source/build information to the project README. Keep the existing
installation guide. The portal repository field should link to that repository.
A downloadable source ZIP is useful, but also publishing the unpacked scripts
makes the code directly reviewable in GitHub.
