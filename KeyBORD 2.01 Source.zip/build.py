from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import argparse, hashlib

parser=argparse.ArgumentParser(description="Build the three KeyBORD NEMESIS packages")
parser.add_argument('--apk',type=Path,required=True,help="Hacker's Keyboard 1.41.1 APK")
parser.add_argument('--out',type=Path,default=Path('dist'))
args=parser.parse_args()
root=Path(__file__).resolve().parent
payload=args.apk.read_bytes()
expected="641ab8a614f496765bb841665aa894fdb9d1f908c22ffb01af2059c7600ed0d3"
if hashlib.sha256(payload).hexdigest()!=expected:
    raise SystemExit('APK checksum differs from the KeyBORD 2.01 payload.')
args.out.mkdir(parents=True,exist_ok=True)
for package in sorted((root/'packages').iterdir()):
    if not package.is_dir():continue
    if not (package/'NEMESIS.data').is_file():raise SystemExit('Missing descriptor: '+str(package))
    target=args.out/(package.name+'.zip')
    with ZipFile(target,'w',ZIP_DEFLATED) as z:
        for f in sorted(package.rglob('*')):
            if f.is_file():z.write(f,f.relative_to(package).as_posix())
        if package.name=='keyboard.hackers':z.writestr('app/HackersKeyboard.apk',payload)
    print(target)
